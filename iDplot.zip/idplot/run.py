import os
os.system("python setup.py install")