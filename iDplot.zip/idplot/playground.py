import numpy as np
from idplot import self_plot

x = np.linspace(0, 100)
y1 = np.power(x, 2)
y2 = np.power(x, 3)
y3 = np.power(x, 4)

data1 = {'x': x, 'y': y1}
data2 = {'x': x, 'y': y2}
data3 = {'x': x, 'y': y3}
data = [data1, data2, data3]

self_plot(data, 
          './test.tiff',
          xlabel='Xlabel',
          ylabel='Ylabel',
          legend=[r'$\alpha$=  5e-4', r'$\alpha$=  7e-4', r'$\alpha$=10e-4'],
          legend_loc='lower right',)
