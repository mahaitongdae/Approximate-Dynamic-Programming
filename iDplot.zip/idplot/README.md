# idplot
# 使用说明

运行 `run.py` 进行安装，之后直接`import idplot`即可。

----------

编译

```
python setup.py build
```

压缩 生成*.egg文件，支持easy_install安装
```
python setup.py bdist_egg
```

打包 生成*.zip/*.tar.gz文件，支持pip安装
```
python setup.py sdist
```

生成.whl文件
```
python setup.py bdist_wheel
```

安装
```
python setup.py install 
easy_install xx.egg
easy_install xx
pip install xx.whl
```